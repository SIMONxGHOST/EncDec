package com.example.crypto

data class KeyProfile(
    val id: String,
    val alias: String,
    val saltLength: Int,
    val memoryMb: Int,
    val scryptN: Int,
    val scryptR: Int = 8,
    val scryptP: Int = 1,
    val legacyIterations: Int,
    val rating: String,
    val description: String,
    val cipher: String = "AES-256-GCM",
    val badgeColorHex: Long = 0xFF38BDF8
) {
    // Keep backward-compatible property for any existing references
    val iterations: Int get() = legacyIterations

    companion object {
        val ALL_PROFILES = listOf(
            KeyProfile("Key 1", "Key 1", 32, 1, 1024, 8, 1, 100_000, "Ultra-Fast", "Instant Mobile • 1MB RAM", "AES-256-GCM", 0xFF10B981),
            KeyProfile("Key 2", "Key 2", 32, 2, 2048, 8, 1, 200_000, "Fast", "Fast Mobile • 2MB RAM", "AES-256-GCM", 0xFF22C55E),
            KeyProfile("Key 3", "Key 3", 32, 4, 4096, 8, 1, 300_000, "Light", "Lightweight Vault • 4MB RAM", "AES-256-GCM", 0xFF38BDF8),
            KeyProfile("Key 4", "Key 4", 32, 8, 8192, 8, 1, 400_000, "Standard", "Standard Mobile • 8MB RAM", "AES-256-GCM", 0xFF6366F1),
            KeyProfile("Key 5", "Key 5", 32, 16, 16384, 8, 1, 500_000, "Enhanced", "Enhanced Vault • 16MB RAM", "AES-256-GCM", 0xFF818CF8),
            KeyProfile("Key 6", "Key 6", 32, 32, 32768, 8, 1, 800_000, "High", "High Security AEAD • 32MB RAM", "AES-256-GCM", 0xFFA855F7),
            KeyProfile("Key 7", "Key 7", 32, 64, 65536, 8, 1, 1_000_000, "High+", "High+ Vault Grade • 64MB RAM", "AES-256-GCM", 0xFFC084FC),
            KeyProfile("Key 8", "Key 8", 32, 128, 131072, 8, 1, 1_200_000, "Strong", "Strong Supercomputer • 128MB RAM", "AES-256-GCM", 0xFFF43F5E),
            KeyProfile("Key 9", "Key 9", 32, 256, 262144, 8, 1, 1_500_000, "Extreme", "Military Vault Grade • 256MB RAM", "AES-256-GCM", 0xFFF59E0B),
            KeyProfile("Key 10", "Key 10", 32, 512, 524288, 8, 1, 2_000_000, "Paranoid", "Quantum / ASIC Proof • 512MB RAM", "AES-256-GCM", 0xFFEF4444)
        )

        val DEFAULT = ALL_PROFILES[3] // Key 4 (Standard - 8MB)

        fun fromAlias(name: String): KeyProfile {
            val clean = name.trim().lowercase()
            return ALL_PROFILES.firstOrNull {
                it.alias.lowercase() == clean ||
                it.id.lowercase() == clean ||
                clean.contains(it.alias.lowercase()) ||
                (clean.contains("vault 10") && it.alias == "Key 10") ||
                (clean.contains("vault 9") && it.alias == "Key 9") ||
                (clean.contains("vault 8") && it.alias == "Key 8") ||
                (clean.contains("vault 7") && it.alias == "Key 7")
            } ?: DEFAULT
        }
    }
}
